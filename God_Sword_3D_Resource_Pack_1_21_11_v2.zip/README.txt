God Sword 3D — Minecraft Java 1.21.11 (vanilla, no mods needed)
Rename a Golden Sword in an anvil to: Меч Бога
Also works with the gradient name (&#FFFFFFМ&#F7F7DBе...).
